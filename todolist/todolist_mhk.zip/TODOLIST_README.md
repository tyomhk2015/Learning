# 実装を見る方法

## problem8.html（paginationの課題）
htmlファイルをそのままで開けますと実装が見れます。

## TODOLIST
Zipファイルの内容を解凍した後にいずれのコマンドを実行してください。

＞ npm install 
又は
＞ yarn install

で必須なdependencyをダウンロードします。


そして
＞ npm start
又は
＞ yarn start

でローカルサーバを立ちます。
